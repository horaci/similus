$:.unshift "#{File.dirname(__FILE__)}/lib"
require 'similus'
