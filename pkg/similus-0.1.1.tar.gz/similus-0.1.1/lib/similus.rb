require 'rubygems'
require 'redis'

require File.join(File.dirname(__FILE__), 'similus', 'core.rb')
require File.join(File.dirname(__FILE__), 'similus', 'config.rb')
require File.join(File.dirname(__FILE__), 'similus', 'redis.rb')
